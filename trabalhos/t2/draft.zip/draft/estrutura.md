# Introducao

# Objetivos

# Othello

Comentar sobre o que é o jogo, seu estado inicial, suas regras de captura, etc..., assim como na visão geral

### Variante circular

Descrever o que muda no estado inicial do jogo.
Descrever as mudanças nas regras de capturas.

Explicar no que isso muda nas estratégias do jogo normal.
Por que essa variante é interessante.

# Agentes

## MCTS

## Minimax

### Heurísticas

Comentar sobre como isso foi organizado no código. Comentar que cada avaliador retornam uma quantidade fixa de parâmetros que são multiplicados pelos pesos.

### Heurística de Material

### Heurística de Posição

### Heurística de Mobilidade Potencial

### Heurística de Paridade

### Composição de heurísticas

Explicar o avaliador composto e o avaliador sensível a fase. Explicar cada fase.

### Definição dos avaliadores e dos seus pesos

Comentar que foi definido o avaliador denominado SCE1 que somente usa a contagem de peças.

Foi criado um avaliador combinando todas 

Variante classica

CEE -> pesos escolhidos a mao. Apresetar quais como a funçao de avaliação é composta

```
CLASSICAL_EMPIRIC_EVALUATOR = PhaseAwareEvaluator(
    opening=CompositeEvaluator([
        PositionalEvaluator(scale=0.4),
        CountEvaluator(scale=0.2),
        PotentialMobilityEvaluator(scale=0.2)
    ]),
    midgame=CompositeEvaluator([
        PositionalEvaluator(scale=0.3),
        CountEvaluator(scale=0.4),
        PotentialMobilityEvaluator(scale=0.2)
    ]),
    endgame=CompositeEvaluator([
        CountEvaluator(scale=0.7),
        PositionalEvaluator(scale=0.2),
        PotentialMobilityEvaluator(scale=0.1)
    ]),
    name='CEE1'
)
```

#### Variante clássica

definiu-se um avaliador que engloba todas as carectristicas por fase s seus pesos são ajustados de acordo com o critéiro. A estrutura do avaliador que teve seus pesos ajustados é:

```
evaluator = PhaseAwareEvaluator(
    opening=CompositeEvaluator([
        CountEvaluator(),
        PositionalEvaluator(),
        PotentialMobilityEvaluator(),
        ParityEvaluator()
    ]),
    midgame=CompositeEvaluator([
        CountEvaluator(),
        PositionalEvaluator(),
        PotentialMobilityEvaluator(),
        ParityEvaluator()
    ]),
    endgame=CompositeEvaluator([
        CountEvaluator(),
        PositionalEvaluator(),
        PotentialMobilityEvaluator(),
        ParityEvaluator()
    ])
)
```

- CWTE1 treinado usando regressao logistica para prever quando as brancas ganham.
- CSTE1 treinado usando regressao linear para prever a pontuação final na perspectiva das brancas.

- MCTS com 10000 iteracoes contra MCTS com 10000 interacoes
- 0 a 7 movimentos aleatorios antes do MCTS
- 700 partidas (377 brancas, 281 pretas e 42 empates)
- 20065 movimentos
Aproxidamente 57 horas de simulação

#### Variante circular

- WWTE1 treinado usando regressao logistica para prever quando as brancas ganham.
- WSTE1 treinado usando regressao linear para prever a pontuação final na perspectiva das brancas.

- MCTS com 5000 iteracoes contra MCTS com 5000 interacoes
- (1305 pretas, 1226 brancas, 169 empates)
- 76975 movimentos
- aproximadamente 104 horas de simulação


# Análises experimentais

Simulações em torneios, jogando cada configuração de agente minimax contra cada configuração de agente MCTS. O mesmo número de partidas jogando como brancas e jogando como pretas.

Variante classica:
- PC para as simulações com a variante clássica:
- i5 14600KF e 32GB de ram
- 14 núcleos físicos
- Minimax com avaliadores (SCE1, CWTE1 e CSTE1) profundidades entre 1 a 6 contra MCTS com iteracoes 2500, 5000, 7500 e 1000.
- Cada combinacao teve 126 partidas simuladas (73 com o minimax jogando como brancas e 73 como pretas)
- Exceto nas combinacoes que incluem o SCE1, que foram simuladas somente 14 partidas (7 jogando como brancas e 7 como pretas) 


Variante circular:
- Ryzen 7 6800H e 16GB de ram
- 8 núcleos físicos
- Minimax com avaliadores (SCE1, CWTE1, WWTE1 e WSTE1) profundidades entre 1 a 6 contra MCTS com iteracoes 2500, 5000, 7500 e 1000.
- Cada combinação teve 56 partidas simuladas (23 com o minimax jogando como brancas e 23 como pretas)
- Exceto nas combinacoes que incluem o SCE1, que foram simuladas somente 14 partidas (7 jogando como brancas e 7 como pretas) 

# Resultados e discussão

## Variante clássica

- Total de 9408 partidas com 307277 turnos.
- cerca 118 horas de simulações. 

### Taxas de vitória

### Impacto dos parâmetros

#### Eficácia da poda

### Estratégias de jogo

## Variante circular
- Total de 5726 partidas com 183971 turnos.
- cerca 84 horas de simulações. 

### Taxas de vitória

### Estratégias de jogo

# Considerações finais