# Trabalho de Inteligência Artificial

### Desenvolvimento de Agentes Inteligentes para Othello: Min-Max com Poda

### Alfa-Beta e Monte Carlo Tree Search

### Prof. Luis Alvaro

### Abril 2026

## 1 Objetivo

Desenvolver agentes inteligentes para um jogo utilizando duas abordagens clássicas de busca
em Inteligência Artificial:

- Min-Max com poda Alfa-Beta
- Monte Carlo Tree Search (MCTS)
O objetivo é comparar essas abordagens em termos de desempenho, custo computacional
e qualidade das decisões. O trabalho será desenvolvido sobre o jogo Othello (Reversi) em
um tabuleiro 6x6. Cada grupo deve implementar:
- Representação do estado do jogo
- Geração de jogadas válidas
- Regras de captura de peças
- Atualização do tabuleiro
- Condição de término
- Cálculo do vencedor
Extensão obrigatória: cada grupo deve propor pelo menos uma modificação não
trivial no jogo, como:
- alteração no tamanho do tabuleiro (ex.: 5x5, 7x7)
- nova regra de pontuação
- restrições adicionais de jogada
- variação nas regras de captura


## 2 Parte 1: Agente Min-Max com poda Alfa-Beta

Implementar um agente baseado em:

- Algoritmo Min-Max
- Poda Alfa-Beta
- Profundidade limitada (entre 3 e 5 níveis)
O grupo deve:
- Construir manualmente uma árvore de decisão (mínimo 2 níveis)
- Mostrar valores propagados
- Indicar explicitamente onde ocorre poda

## 3 Parte 2: Função de Avaliação

Definir uma função de avaliação heurística baseada em pelo menos três características
do jogo. Exemplos de características:

- Diferença de número de peças
- Mobilidade (número de jogadas possíveis)
- Controle de cantos
- Controle de bordas
- Estabilidade de peças
A função deve seguir o formato:

Avaliar(s) = \sum_i w_i f_i(s)

- Justificar cada característica
- Explicar a escolha dos pesos
- Discutir como a heurística influencia o comportamento do agente


## 4 Parte 3: Agente Monte Carlo Tree Search (MCTS)

Implementar um agente baseado em MCTS contendo:

- Seleção (ex.: UCT)
- Expansão
- Simulação (rollout)
- Retropropagação
O grupo deve definir:
- Número de simulações ou limite de tempo
- Estratégia de simulação (aleatória ou heurística)
- Critério de parada

## 5 Parte 4: Análise Experimental

Comparar os agentes Min-Max e MCTS:

- Taxa de vitória
- Impacto da profundidade (Min-Max)
- Impacto do número de simulações (MCTS)

## 6 Discussão, entregas e apresentação

O relatório deve discutir:

- Diferenças entre busca baseada em heurística (Min-Max) e simulação (MCTS)
- Limitações de cada abordagem
- Situações onde cada algoritmo se destaca
As entregas devem conter:
- Código-fonte em Python (comentado)
- Relatório em PDF
- Vídeo de até 5 minutos explicando a solução


Todos os trabalhos devem ser apresentados de forma oral para o professor. O trabalho
será considerado como não entregue para aqueles que não apresentarem. Na apresentação
oral, os grupos poderão ser questionados sobre:

- Funcionamento interno dos algoritmos
- Decisões de modelagem
- Interpretação dos resultados experimentais
Observação: A avaliação considerará a coerência entre implementação, resultados e
explicações.


