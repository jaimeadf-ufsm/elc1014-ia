# Documento Técnico das Pipelines de Análise

## 1. `summary`
### O que a análise apresenta
Esta pipeline gera um resumo textual consolidado do estudo, contendo:
- total de partidas;
- total de turnos (jogadas executadas);
- tempo total gasto em decisões de jogada;
- desempenho por confronto único `Preto vs Branco`, sempre na perspectiva do agente preto (vitórias, derrotas, empates e taxa de vitória).

### Como o resultado deve se parecer
O resultado é um texto estruturado impresso no terminal e salvo em `summary/resumo.txt`, com uma seção geral e uma lista por matchup.

### Insights esperados
Permite identificar rapidamente o volume da base analisada e quais pares de agentes favorecem mais o lado preto, com comparação direta entre configurações específicas.

---

## 2. `win_heatmap`
### O que a análise apresenta
Esta pipeline constrói mapas de calor de taxa de vitória do Minimax contra MCTS, indexados por:
- eixo X: número de iterações do MCTS;
- eixo Y: profundidade do Minimax.

Para cada avaliador do Minimax, são gerados 3 gráficos:
- Minimax jogando de Brancas;
- Minimax jogando de Pretas;
- Minimax em qualquer cor.

### Como o resultado deve se parecer
Para cada avaliador, há uma pasta dedicada com três arquivos `.png`. Cada célula do heatmap exibe a taxa de vitória do Minimax (em percentual) na combinação profundidade/iterações.

### Insights esperados
Permite observar o equilíbrio entre custo computacional (profundidade vs iterações) e desempenho competitivo, além de revelar sensibilidade do Minimax à cor inicial.

---

## 3. `average_time_minimax`
### O que a análise apresenta
Esta pipeline plota o tempo médio por jogada do Minimax:
- eixo X: profundidade;
- eixo Y: tempo médio por jogada (segundos);
- uma linha por avaliador.

### Como o resultado deve se parecer
Um gráfico de linhas único, com múltiplas séries (uma para cada avaliador), mostrando crescimento de tempo conforme a profundidade.

### Insights esperados
Evidencia o custo operacional de cada avaliador no Minimax, apoiando escolhas de configuração com melhor relação desempenho x tempo.

---

## 4. `average_time_mcts`
### O que a análise apresenta
Esta pipeline plota o tempo médio por jogada do MCTS:
- eixo X: iterações;
- eixo Y: tempo médio por jogada.

### Como o resultado deve se parecer
Um gráfico de linha crescente (em geral), mostrando o efeito direto de aumentar iterações no tempo de decisão.

### Insights esperados
Mostra a escalabilidade temporal do MCTS e ajuda a selecionar limites de iteração adequados ao orçamento de tempo.

---

## 5. `average_time_per_turn`
### O que a análise apresenta
Esta pipeline calcula o tempo médio por turno (`state.count`) para cada configuração única de agente:
- eixo X: número do turno;
- eixo Y: tempo médio por jogada;
- uma linha por agente.

### Como o resultado deve se parecer
Um gráfico com várias linhas, cada uma representando uma configuração de agente, mostrando variação de custo ao longo da partida.

### Insights esperados
Permite identificar em quais fases do jogo cada agente tende a ficar mais lento, revelando padrões de complexidade ao longo do match.

---

## 6. `total_states_explored_minimax`
### O que a análise apresenta
Esta pipeline soma o total de estados explorados pelo Minimax:
- eixo X: profundidade;
- eixo Y: total de estados explorados;
- uma linha por avaliador.

### Como o resultado deve se parecer
Um gráfico de linhas com crescimento acentuado conforme a profundidade, comparando impacto do avaliador no volume de busca.

### Insights esperados
Mede custo global de exploração e ajuda a comparar eficiência prática entre avaliadores sob diferentes profundidades.

---

## 7. `average_states_explored_pruned_minimax`
### O que a análise apresenta
Esta pipeline gera um gráfico de barras empilhadas para cada configuração única de Minimax, mostrando por nível da árvore:
- média de estados explorados;
- média de estados podados;
- normalização por nível (cada profundidade com escala própria).

### Como o resultado deve se parecer
Uma imagem por configuração de Minimax, com barras empilhadas entre 0 e 1, onde cada barra representa a composição relativa explorado/podado naquele nível.

### Insights esperados
Permite avaliar a eficiência da poda alfa-beta por camada da busca, destacando onde a poda está efetiva ou insuficiente.

---

## 8. `piece_placement_heatmap`
### O que a análise apresenta
Esta pipeline cria mapas de calor de posicionamento de peças por agente, contando quantas vezes cada casa recebeu jogada de colocação.

Para cada configuração única de agente, são gerados:
- mapa jogando de Brancas;
- mapa jogando de Pretas;
- mapa considerando qualquer cor.

### Como o resultado deve se parecer
Uma pasta por agente com três heatmaps do tabuleiro (6x6), cada célula anotada com a frequência de posicionamento.

### Insights esperados
Expõe preferências posicionais do agente, permitindo comparar estilo estratégico (controle de bordas, cantos, centro etc.).

---

## 9. `piece_capture_heatmap`
### O que a análise apresenta
Esta pipeline cria mapas de calor de captura por agente, contando a frequência com que cada casa foi capturada em jogadas do agente.

Para cada configuração única de agente, são gerados:
- mapa jogando de Brancas;
- mapa jogando de Pretas;
- mapa considerando qualquer cor.

### Como o resultado deve se parecer
Uma pasta por agente com três heatmaps do tabuleiro, onde valores maiores indicam regiões de captura recorrentes.

### Insights esperados
Ajuda a identificar zonas de pressão tática e padrão de conversão de peças do oponente por configuração de agente.

---

## Observações de implementação
- Todas as legendas, títulos e rótulos dos gráficos foram implementados em português brasileiro.
- Cada gráfico é salvo em arquivo individual dentro de uma subpasta nomeada pela pipeline.
- Foi adicionada também a pipeline `all`, que executa todas as análises em sequência para facilitar geração completa dos artefatos.
