# Comparação de Agentes de Busca em Othello: Minimax versus Monte Carlo Tree Search

**Autor:** MiniMax Agent

**Resumo:** Este artigo apresenta uma investigação sistemática sobre o desempenho de dois paradigmas algorítmicos fundamentais em jogos de tabuleiro — o algoritmo Minimax com poda alfa-beta e o algoritmo Monte Carlo Tree Search (MCTS) — aplicados ao jogo Othello em sua variante circular (WrapAround). O estudo examina seis funções de avaliação distintas, incluindo avaliadores clássicos baseados em heurísticas posicional e material, bem como avaliadores ajustados por aprendizado de máquina através de regressão logística e regressão linear. A metodologia emprega confrontos entre agentes Minimax e MCTS com variados parâmetros de profundidade e iterações, produzindo métricas detalhadas de desempenho, tempo computacional e comportamento estratégico. Os resultados revelam características distintas de cada abordagem, oferecendo insights sobre os trade-offs entre qualidade de decisão e custo computacional em ambientes de busca adversarial.

---

## 1. Introdução

### 1.1 Contextualização do Problema

Os jogos de tabuleiro bipartidários têm servido como laboratório privilegiado para o desenvolvimento e refinamento de algoritmos de decisão em inteligência artificial desde os primórdios da computação. A natureza determinística, de informação perfeita e adversarial desses jogos oferece um domínio controlado onde é possível medir com precisão a qualidade das decisões tomadas por diferentes agentes. O estudo pioneiro de Claude Shannon em 1950 estabeleceu os fundamentos teóricos para a construção de programas de xadrez, distinguindo entre estratégias baseadas em busca exaustiva e aquelas fundamentadas em avaliação posicional. Essa dualidade conceptual permanece como um fio condutor em toda a pesquisa subsequente em jogos algorítmicos, manifestando-se de forma particularmente rica no jogo Othello.

O Othello, também conhecido como Reversi, distingue-se de outros jogos de tabuleiro clássicos por sua natureza dinâmica e pela dificuldade de estabelecer vantagem material early no jogo. Diferentemente do xadrez, onde peças de diferentes valores podem ser exchangeadas, no Othello todas as peças são equivalentes e ganham valor ou desvalorizam conforme sua posição no tabuleiro evolui. Essa característica torna o jogo particularmente desafiador para algoritmos baseados em heurísticas, pois o valor de uma posição não pode ser determinado exclusivamente pela contagem de peças, mas depende de fatores posicionais complexos como controle de bordas, proximidade dos cantos e potencial de mobilidade futura.

A escolha do Othello como domínio de estudo neste trabalho deve-se a várias propriedades que o tornam um intermediário ideal entre jogos mais simples e aqueles com espaços de estados astronomicamente grandes. O tabuleiro de dimensões reduzidas utilizado nesta investigação (6×6 casas) permite a realização de experimentos computacionalmente viáveis com múltiplos parâmetros, ao mesmo tempo em que preserva as complexidades estratégicas essenciais do jogo completo. Ademais, a inclusão de uma variante circular (WrapAround) adiciona uma camada adicional de интерес, modificando fundamentalmente as linhas de captura e eliminando as vantagens tradicionais associadas às posições de canto.

### 1.2 Objetivos do Trabalho

Este trabalho tem como objetivo principal realizar uma comparação sistemática entre dois paradigmas algorítmicos distintos para tomada de decisão em jogos de tabuleiro: o algoritmo Minimax com poda alfa-beta, representante clássico da busca determinística em árvores de jogo, e o algoritmo Monte Carlo Tree Search, representante da busca probabilística baseada em simulações aleatórias. A comparação busca identificar as condições em que cada abordagem oferece vantagens perceptíveis, tanto em termos de taxa de vitória quanto em termos de eficiência computacional.

Especificamente, o trabalho visa examinar como diferentes funções de avaliação (heurísticas) afetam o desempenho do algoritmo Minimax, desde avaliadores simples baseados exclusivamente em contagem de material até avaliadores sofisticados que combinam múltiplos fatores posicionais e são ajustados por técnicas de aprendizado de máquina. A investigação também busca compreender como a profundidade de busca no Minimax e o número de iterações no MCTS influenciam a qualidade das decisões e o tempo necessário para produzi-las.

Um objetivo adicional é avaliar o impacto da variante circular (WrapAround) nas estratégias óptimas de jogo. Ao modificar as regras de captura de modo que peças posicionadas sobre as diagonais principais possuam linhas de visão que atravessam as bordas do tabuleiro, esta variante elimina muitas das heurísticas posicionals tradicionais e cria um ambiente onde outras características do jogo assumem maior relevância estratégica.

### 1.3 Relevância da Comparação

A comparação entre Minimax e MCTS transcende o domínio específico do Othello, tocando em questões fundamentais sobre os trade-offs entre buscaexaustiva e amostragem estatística em problemas de decisão sequencial. O algoritmo Minimax representa uma abordagem que busca examinar completamente o espaço de possibilidades até uma profundidade determinada, aplicando julgamento qualitativo apenas nas posições terminais dessa busca. Essa estratégia oferece garantias teóricas sobre a qualidade da decisão (dentro dos limites da profundidade), mas paga um preço computacional que cresce exponencialmente com a profundidade explorada.

O algoritmo MCTS, por outro lado, adota uma filosofia fundamentalmente diferente. Em vez de tentar avaliar cada possibilidade, o método concentra seus recursos computacionais em regiões promissoras da árvore de jogo, utilizando simulações aleatórias para estimar o valor de posições não-exploradas. Essa abordagem oferece uma escalabilidade mais favorável em espaços de estados amplos, mas sua eficácia depende criticamente da qualidade das políticas de simulação e seleção empregadas.

Compreender quando cada paradigma oferece vantagens perceptíveis tem implicações práticas significativas para o design de sistemas de IA em jogos e além. Domains onde o espaço de estados é demasiado grande para busca exaustiva mas onde heurísticas bem-definidas não estão disponíveis representam territórios naturais para o MCTS. Por outro lado, domínios onde a avaliação posicional é relativamente confiável podem se beneficiar da abordagem Minimax, especialmente quando recursos computacionais suficientes estão disponíveis.

---

## 2. Othello: Regras e Características

### 2.1 Tabuleiro e Posicionamento Inicial

O Othello é jogado em um tabuleiro quadrado dividido em casas iguais, onde peças bidimensionais são placed representando os jogadores. Neste estudo, utilizou-se a variante com tabuleiro de 6×6 casas, diferentemente do Othello padrão que emprega tabuleiros de 8×8. A escolha por dimensões reduzidas permite análises computacionalmente viáveis tout preservando as complexidades estratégicas essenciais do jogo.

A configuração inicial do jogo clássico apresenta quatro peças posicionadas no centro do tabuleiro, formando um quadrado com duas peças de cada cor dispostas em diagonal. O jogador que inicia a partida (representado pelas peças pretas neste trabalho) recebe a posição que tradicionalmente oferece maior flexibilidade inicial.

```
   0   1   2   3   4   5
0  .   .   .   .   .   .
1  .   .   .   .   .   .
2  .   .   W   B   .   .
3  .   .   B   W   .   .
4  .   .   .   .   .   .
5  .   .   .   .   .   .

Legenda: W = Peça Branca, B = Peça Preta, . = Casa Vazia
```

Na variante circular (WrapAround), a configuração inicial é substancialmente diferente. As quatro peças iniciais são posicionadas nos cantos do tabuleiro, duas brancas nos cantos superiores e duas pretas nos cantos inferiores, criando um padrão de abertura radicalmente distinto do clássico.

```
   0   1   2   3   4   5
0  W   .   .   .   .   W
1  .   .   .   .   .   .
2  .   .   .   .   .   .
3  .   .   .   .   .   .
4  .   .   .   .   .   .
5  B   .   .   .   .   B

Legenda: W = Peça Branca, B = Peça Preta, . = Casa Vazia
```

Essa diferença fundamental na posição inicial já antecipa as profundas alterações estratégicas que a variante circular introduz, uma vez que os cantos — normalmente posições de segurança máxima no Othello tradicional — tornam-se pontos de partida para linhas de captura circulares.

### 2.2 Regras de Captura

O mecanismo central de captura no Othello baseia-se no princípio do flanqueamento: uma peça é capturada quando fica completamente envolvida por peças do oponente em uma linha reta, seja horizontal, vertical ou diagonal. Para que uma jogada seja legal, ela deve resultar em pelo menos uma captura em qualquer das oito direções possíveis.

Formalmente, ao posicionar uma peça em uma casa vazia, o jogador verifica em cada uma das oito direções se existe uma sequência contígua de peças adversárias seguida, obrigatoriamente, por uma peça do próprio jogador. Se essa configuração for encontrada em qualquer direção, todas as peças adversárias dessa sequência são convertidas para a cor do jogador que executou a captura.

No jogo clássico, as linhas de visão são limitadas pela borda física do tabuleiro. Uma vez que a borda é alcançada sem encontrar uma peça do próprio jogador, a captura naquela direção não se concretiza. Isso confere importância estratégica às posições adjacentes às bordas e, especialmente, aos cantos, que representam pontos onde múltiplas linhas de visão convergem para um mesmo local.

Na variante circular, essa limitação topológica é removida para peças posicionadas sobre as diagonais principais do tabuleiro. Quando uma peça reside sobre a diagonal principal (que conecta o canto superior esquerdo ao inferior direito) ou sobre a diagonal secundária (que conecta o canto superior direito ao inferior esquerdo), sua linha de visão atravessa a borda do tabuleiro e reaparece do lado oposto. Essa conexão periódica transforma fundamentalmente a geometria do jogo.

### 2.3 Passagem de Vez e Final de Jogo

Uma regra fundamental do Othello determina que, se um jogador não possui nenhum movimento legal disponível em sua vez, ele deve passar a vez para o oponente. Essa situação ocorre tipicamente quando todas as casas adjacentes às peças do jogador estão ocupadas, sem opções de flanqueamento válido. Importante mencionar que o oponente jogará duas vezes consecutivas se continuar tendo movimentos disponíveis após o passagem.

A partida termina quando nenhum dos dois jogadores consegue realizar um movimento legal. Isso tipicamente ocorre quando o tabuleiro está completamente preenchido ou quando nenhuma casa vazia oferece oportunidade de captura para qualquer jogador. O vencedor é determinado pela contagem final de peças: o jogador com maior número de peças no tabuleiro vence a partida. No caso de empate (número igual de peças), a partida é declarada sem vencedor.

Essa mecânica de finalização introduz considerações estratégicas importantes, especialmente relacionadas à paridade do número de casas vazias. O jogador que consegue garantir o último movimento frequentemente obtém vantagem significativa, podendo converter peças remanescentes do oponente na jogada final.

### 2.4 Importância Estratégica das Posições

A avaliação de posições no Othello transcende a simples contagem de peças, demandando compreensão de fatores posicionais que influenciam o desfecho da partida. Historicamente,学研究 identificou diversas regiões do tabuleiro com значения estratégicas distintas, que refletem a interactção entre controle de espaço, potencial de mobilidade e vulnerabilidade a reverses táticas.

Os cantos do tabuleiro representam as posições de maior valor estratégico no Othello clássico. Uma vez ocupada, uma peça no canto permanece permanentemente sob controle do jogador que a conquistou, uma vez que não é possível flanquear uma peça a partir do canto em múltiplas direções. Essa imutabilidade contrasta com a maioria das outras posições, onde peças podem ser eventualmente capturadas através de sequences táticas mais elaboradas.

As casas adjacentes aos cantos (frequentemente chamadas de posições C e X) representam o outro extremo do espectro posicional. Ocupar essas casas configura um risco significativo, pois cria oportunidades para o oponente capturar o canto posteriormente. Estrategistas experientes evitam ocupar essas posições a menos que não existam alternativas razoáveis.

As bordas do tabuleiro (excluindo cantos e adjacências) oferecem vantagens moderadas, conferindo controle parcial sobre linhas de captura que se estendem ao longo da borda. O centro do tabuleiro, embora ofereça flexibilidade inicial e potencial de influência em múltiplas direções, tende a ser valorizado principalmente na fase intermediária do jogo, quando peças podem ser rapidamente convertidas em posições mais estáveis.

Na variante circular, essa hierarquia posicional é completamente transformada. Os cantos perdem sua segurança inerente, pois peças posicionadas sobre as diagonais podem ser flanqueadas através de linhas que atravessam o tabuleiro. Simultaneamente, posições antes consideradas vulneráveis podem adquirir valor estratégico diferenciado. Essa redistribuição de importância positional torna a variante particularmente interessante para estudos comparativos.

---

## 3. Arquitetura dos Agentes de Jogo

### 3.1 O Algoritmo Minimax com Poda Alfa-Beta

O algoritmo Minimax representa uma das abordagens mais fundamentais para tomada de decisão em jogos de soma zero bipartidários. A estratégia subjacente assume que cada jogador busca maximizar sua própria vantagem enquanto minimiza a vantagem do oponente, criando uma dinâmica onde os interesses são estritamente opostos. O nome do algoritmo deriva da combinação das estratégias de maximização (para um jogador) e minimização (para o oponente) que são alternadamente aplicadas durante a busca.

A implementação clássica do Minimax funciona explorando recursivamente a árvore de jogo a partir do estado atual, alternando entre nós de maximização e minimização conforme a profundidade aumenta. Na profundidade zero (nós folha), uma função de avaliação estima a qualidade da posição do ponto de vista do jogador que executará o próximo movimento. Esse valor é então propagado de volta através da árvore: em nós de maximização, o maior valor entre os filhos é selecionado; em nós de minimização, o menor valor é propagado. Dessa forma, o algoritmo Assume que ambos os jogadores jogarão ottimalmente a partir de suas perspectivas respectvas.

Para evitar a exploração exaustiva de toda a árvore de jogo (o que seria computacionalmente intratável), o algoritmo emprega um limite de profundidade. Uma vez atingida essa profundidade máxima, os nós são avaliados utilizando a função de avaliação heurística em vez de continuar a busca recursiva. Essa aproximação introduz um trade-off fundamental: profundidades maiores permitem avaliação mais precisa mas demandam exponencialmente mais recursos computacionais.

A poda alfa-beta constitui a principal otimização aplicada ao Minimax básico, permitindo eliminar subárvores inteiras que não podem influenciar a decisão final. O mecanismo funciona mantendo dois valores, alfa e beta, que representam, respectivamente, o melhor valor garantido para o jogador maximizador e o melhor valor garantido para o minimizador em nós ancestrais. Quando, durante a busca, o valor de um nó de maximização se torna maior ou igual ao valor beta de um ancestral minimizador (ou vice-versa), não há necessidade de explorar os irmãos restantes desse nó, pois o ancestral já possui uma opção pelo menos tão boa quanto qualquer coisa que possa ser encontrada nessa subárvore.

A eficácia da poda alfa-beta depende criticamente da ordem em que os movimentos são explorados. No melhor caso, quando os melhores movimentos são examinados primeiro, a poda pode reduzir drasticamente o número de nós avaliados, aproximando-se de uma busca em profundidade com complexidade proporcional à raiz quadrada da árvore completa. No pior caso, quando os piores movimentos são explorados primeiro, a poda oferece pouco benefício e o algoritmo degenera para uma busca completa.

As métricas coletadas durante a execução do Minimax fornecem insights valiosos sobre seu funcionamento interno. O contador de nós explorados indica quantos estados foram efetivamente avaliados durante a busca. O contador de nós podados indica quantas subárvores foram descartadas pela poda alfa-beta. A razão entre esses valores revela a eficácia da poda em diferentes contextos, enquanto a evolução desses números com o aumento da profundidade ilumina como o espaço de busca cresce.

### 3.2 O Algoritmo Monte Carlo Tree Search

O algoritmo Monte Carlo Tree Search (MCTS) representa uma abordagem fundamentalmente diferente para tomada de decisão em jogos, abandonando a avaliação explícita de posições em favor de amostragem estatística através de simulações aleatórias. Desde sua introdução no contexto de jogos de tabuleiro e seu subsequente sucesso no Go, o MCTS tornou-se uma das técnicas mais amplamente utilizadas em planejamento automatizado, demonstrando eficácia em domínios que variam desde jogos clássicos até problemas de logística e robótica.

A estrutura central do MCTS baseia-se em nodes que representam estados do jogo, cada um mantendo estatísticas acumuladas ao longo de múltiplas visitas. Cada nó armazena duas informações fundamentais: o número de vezes que foi visitado durante o processo de busca (n) e a soma acumulada de recompensas observadas em simulações que passaram por esse nó (q). A recompensa é computada do ponto de vista do jogador que executou a jogada que levou ao nó, permitindo que a estatística capture valores relativos.

O algoritmo MCTS opera através de quatro fases distintas que se repetem iterativamente até que um critério de parada seja satisfeito (tipicamente um número fixo de iterações ou um limite de tempo). A primeira fase, chamada seleção, percorre a árvore de jogo a partir da raiz utilizando uma política de seleção que balanceia exploração e exploitation. A formula UCT (Upper Confidence Bound for Trees) é frequentemente empregada para essa finalidade, computando para cada nó filho o valor da média de recompensas acrescido de um termo de exploração que diminui com visitas adicionais ao nó pai e aumenta com visitas adicionais ao nó filho.

Uma vez que um nó é encontrado que ainda não foi completamente expandido (isto é, possui movimentos legais não tentados), a segunda fase, expansão, é executada. Um dos movimentos não explorados é selecionado aleatoriamente e um novo nó é criado como filho. A terceira fase, simulação (ou rollout), prossegue jogando aleatoriamente a partir do novo nó até atingir um estado terminal do jogo. O resultado da simulação (vitória, derrota ou empate) é então registrado.

A quarta e última fase, retropropagação, percorre o caminho inverso desde o nó recém-criado até a raiz, atualizando as estatísticas de cada nó no caminho. Se o resultado favorece o jogador que executou a jogada que levou a um nó, sua estatística q é incrementada positivamente; se o resultado favorece o oponente, q é decrementado negativamente. O contador de visitas n é sempre incrementado para todos os nós no caminho.

O número de iterações executadas pelo MCTS constitui o parâmetro mais crítico para seu desempenho, controlando diretamente o trade-off entre qualidade da decisão e tempo de computação. Com poucas iterações, a árvore de busca permanece pequena e as decisões baseiam-se em estatísticas com alta variância. Aumentar o número de iterações refina progressivamente as estimativas de valor, permitindo que o algoritmo identifique movimentos genuinamente superiores com maior confiança.

A constante de exploração c presente na fórmula UCT representa outro parâmetro ajustável que influencia o comportamento do algoritmo. Valores maiores incentivam a exploração de movimentos menos visitados, sendo particularmente úteis em fases iniciais quando as estatísticas ainda são escassas. Valores menores focam a busca nas opções aparentemente melhores, sendo mais apropriados quando as estimativas de valor são relativamente confiáveis.

Uma característica distintiva do MCTS é que ele não requer uma função de avaliação heurística explícita. Em vez disso, a avaliação emerge naturalmente das estatísticas acumuladas ao longo das simulações. Isso torna o algoritmo particularmente adequado para domínios onde heurísticas precisas são difíceis de formular, embora também signifique que o MCTS pode requerer mais iterações para atingir desempenho comparável a Minimax bem configurado em domínios onde boas heurísticas estão disponíveis.

---

## 4. Funções de Avaliação (Heurísticas)

### 4.1 Princípio da Avaliação Posicional

A qualidade das decisões tomadas pelo algoritmo Minimax depende criticamente da função de avaliação empregada para estimar o valor de posições não-terminais. Essa função transforma o estado completo do jogo (tabuleiro, próximo jogador, movimentos legais) em um número real que representa a desirabilidade da posição. O princípio fundamental que guia o design de heurísticas para Othello é que o valor de uma posição não pode ser reduzido à simples contagem de peças, devendo incorporar múltiplos fatores que influenciam o resultado final da partida.

O sistema de pesos adotado neste trabalho segue uma arquitetura unificada onde cada avaliador mantém um vetor de pesos que indica a importância relativa de diferentes parâmetros extraídos do estado do jogo. A pontuação final é computada como a soma ponderada dos parâmetros, onde cada parâmetro é multiplicado pelo seu peso correspondente e os resultados são agregados. Formalmente, a avaliação de um estado é expressa como o produto interno entre o vetor de pesos e o vetor de parâmetros.

Uma característica fundamental desse sistema de pesos é que a maioria dos avaliadores mantém pesos separados para peças brancas e peças pretas. Essa separación permite que o modelo capture estratégias assimétricas onde cada lado pode ter importâncias diferentes para cada fator avaliado. Por exemplo, o modelo pode aprender que ter peças brancas no canto é muito valioso, mas também pode aprender que ter peças pretas no canto é igualmente valioso (porém com sinal invertido, pois quando negativo significa que a posição é boa para as brancas). Essa independência permite capturar nuances estratégicas onde cada cor pode valorizar fatores diferentes ao longo da partida.

Para ilustrar o mecanismo de pesos, considere o avaliador de material (SCE1) como exemplo concreto. Os pesos padrão desse avaliador são definidos como [1.0, -1.0], o que significa que cada peça branca contribui +1.0 para a pontuação, e cada peça preta contribui -1.0. Assim, uma posição com 10 peças brancas e 8 pretas teria pontuação calculada como 10×1.0 + 8×(-1.0) = 2.0, indicando vantagem para as brancas. Se os pesos fossem ajustados para [1.2, -0.8], a mesma posição produziria 10×1.2 + 8×(-0.8) = 12.0 - 6.4 = 5.6, refletindo uma avaliação mais favorável à vantagem material das brancas.

O avaliador de posição (regiões do tabuleiro) exemplifica o uso de pesos separados com maior complexidade. Este avaliador mantém 12 pesos: 6 para peças brancas nas diferentes regiões e 6 para peças pretas nas mesmas regiões. Os pesos para peças brancas podem ser interpretados diretamente como valores positivos quando uma posição é vantajosa para as brancas. Os pesos para peças pretas, sendo negativos, indicam que quando presentes em posições positivas, eles reduzem a avaliação (pois são multiplicados pelo sinal negativo).

### 4.2 Avaliador de Material (SCE1)

O Avaliador de Contagem Simples representa a heurística mais elementar do sistema, quantificando a vantagem material direta através da diferença entre o número de peças brancas e pretas no tabuleiro. Este avaliador calcula dois parâmetros normalizados pelo total de casas do tabuleiro: a fração de peças brancas e a fração de peças pretas. A normalização asegura que a avaliação seja comparável independentemente do estágio da partida.

Os parâmetros são computados através de contagem direta das peças no tabuleiro. Para cada estado de jogo, o avaliador determina quantas peças de cada cor estão presentes, divide pelo número total de casas (36 para o tabuleiro 6×6), e armazena esses valores normalizados em um vetor de parâmetros de dimensão dois.

Com os pesos padrão [1.0, -1.0], a avaliação retorna simplesmente a diferença normalizada entre peças brancas e pretas. Uma pontuação positiva indica que há mais peças brancas no tabuleiro; uma pontuação negativa indica vantagem para as pretas; e pontuação próxima de zero indica equilíbrio material. Essa métrica captura a vantagem material direta, sendo especialmente útil no final do jogo quando poucas peças permanecem e o resultado da contagem final pode ser antecipado.

O avaliador de material, embora simples, possui limitações conhecidas. Ele não considera a qualidade posicional das peças, tratando igualmente uma peça estrategicamente dominante e uma peça vulnerável à captura. Também ignora fatores dinâmicos como potencial de mobilidade e controle de espaço. Apesar dessas limitações, o avaliador serve como baseline importante e frequentemente produz resultados razoáveis, especialmente em situações onde a vantagem material é esmagadora.

### 4.3 Avaliador de Posição (Regiões do Tabuleiro)

O Avaliador Posicional introduz considerações estratégicas geográficas, reconhecendo que diferentes regiões do tabuleiro oferecem vantagens e riscos distintos. O tabuleiro 6×6 é dividido em seis regiões distintas, cada uma caracterizada por um conjunto específico de casas com propriedades posicionais similares. Essa divisão reflete séculos de sabedoria estratégica acumulados pela comunidade de jogadores de Othello.

A região zero, correspondente aos quatro cantos do tabuleiro, recebe os pesos de maior magnitude positiva para peças brancas (+1.0) e negativa para peças pretas (-1.0). Essa configuração reflete o valor supremo dos cantos no Othello tradicional, onde peças capturadas são permanentemente seguras. A região um, composta pelas casas diretamente adjacentes aos cantos (posições C), recebe pesos negativos (-0.25 para brancas, +0.25 para pretas), refletindo o perigo de ocupar essas casas, pois facilitam o oponente a capturar os cantos adjacentes.

A região dois, chamada de posições X, compreende as casas diagonais aos cantos. No tabuleiro 6×6, essas são as casas nas coordenadas (1,1), (1,4), (4,1) e (4,4). Os pesos padrão (-0.50 para brancas, +0.50 para pretas) indicam um perigo intermediário entre cantos e posições adjacentes, sendo configurados com magnitude moderada para penalizar sua ocupação sem tornar a penalidade proibitiva.

A região três, correspondendo às bordas centrais do tabuleiro (excluindo cantos e adjacências), recebe pesos modestos (+0.10 para brancas, -0.10 para pretas). O valor positivo reflete a utilidade dessas posições para controle de linhas de captura ao longo das bordas. A região quatro, o anel interno próximo ao centro, recebe pesos ainda mais modestos (+0.05/-0.05), reconhecendo seu papel de flexibilidade sem domínio territorial significativo.

A região cinco, finalmente, corresponde ao centro do tabuleiro. Com pesos mínimos (+0.01/-0.01), essa região é tratada como relativamente neutra do ponto de vista posicional, embora a configuração específica do tabuleiro possa fazer com que o controle do centro influencie outras regiões.

Os parâmetros são computados como frações normalizadas pelo número de casas em cada região. Para cada região, o avaliador conta quantas peças brancas e pretas estão presentes, divide pelo total de casas naquela região, e atribui esses valores aos parâmetros correspondentes. Essa normalização permite comparação equitativa entre regiões de tamanhos diferentes.

### 4.4 Avaliador de Mobilidade Potencial (Fronteira)

O Avaliador de Mobilidade Potencial quantifica a exposição de cada jogador através do conceito de peças na fronteira. Uma peça é considerada "de fronteira" quando está adjacente a pelo menos uma casa vazia, independentemente da direção. Esse conceito captura a intuição de que peças posicionadas no interior do tabuleiro, completamente cercadas por outras peças, oferecem menos opções tanto para o próprio jogador quanto para o oponente.

Do ponto de vista estratégico, peças na fronteira representam investimento de recursos em posições que não contribuem diretamente para o controle territorial. Cada casa vazia adjacente a uma peça do jogador representa uma potencial "janela" que o oponente pode explorar para avançar. Minimizar a própria exposição enquanto maximiza a exposição do oponente constitui uma estratégia defensiva sólida.

Os parâmetros do avaliador são computados como frações normalizadas pelo total de casas do tabuleiro: a fração de peças brancas na fronteira e a fração de peças pretas na fronteira. A normalização permite que a métrica seja comparada independentemente do estágio da partida.

Com os pesos padrão [-1.0, 1.0], o avaliador penaliza a presença de peças brancas na fronteira (contribuição negativa reduz a avaliação) enquanto recompensa a presença de peças pretas na fronteira (contribuição positiva aumenta a avaliação). O resultado líquido é que ter menos peças brancas expostas e mais peças pretas expostas aumenta a pontuação, premiando o jogador que minimiza sua própria exposição enquanto maximiza a do oponente.

O algoritmo para computar peças na fronteira itera sobre todas as casas do tabuleiro. Para cada casa ocupada por uma peça do jogador em questão, verifica se alguma das oito direções contém uma casa vazia dentro dos limites do tabuleiro (ou respeitando a lógica de wraparound se aplicável). Se pelo menos uma direção oferecer casa vazia, a peça é contada como fronteira.

### 4.5 Avaliador de Paridade

O Avaliador de Paridade captura uma característica fundamental do final de jogo no Othello: a vantagem do último movimento. Quando o tabuleiro possui número par de casas vazias e é a vez das brancas, as brancas jogarão por último (pois os dois jogadores consumirão um número par de movimentos para preencher os vazios). Quando o tabuleiro possui número ímpar de casas vazias e é a vez das brancas, as pretas farão o último movimento.

A intuição por trás dessa heurística é que o último movimento pode ser decisive, especialmente quando permite converter peças remanescentes do oponente que não podem ser defendidas. Em posições onde o resultado final depende de poucas peças, a paridade pode determinar o vencedor.

O parâmetro único do avaliador é definido como 1.0 se a paridade atual favorece as brancas (isto é, se as brancas farão o último movimento), e 0.0 caso contrário. A computação verifica se o número de casas vazias é par ou ímpar, comparando com o jogador atual para determinar quem beneficiará.

Com o peso padrão de 1.0, o avaliador adiciona um bônus constante sempre que a situação de paridade for vantajosa para as brancas. Isso captura um aspecto importante do fim de jogo, embora a implementação simples signifique que o avaliador não distingue entre situações onde a paridade é mais ou menos критические.

### 4.6 Avaliador Compositor e Sensível à Fase

O Avaliador Empírico Clássico (CEE1) representa uma evolução sofisticada na arquitetura de avaliação, combinando múltiplos avaliadores simples em uma única função de avaliação composta. A combinação permite que diferentes aspectos do jogo sejam considerados simultaneamente, capturando interações entre material, posição e mobilidade que avaliadores individuais não conseguiriam expressar.

A composição é implementada concatenando os parâmetros e pesos dos avaliadores componentes, produzindo um vetor de parâmetros unificado que representa todas as características extraídas. A avaliação final é computada como a soma ponderada desse vetor, exatamente como nos avaliadores simples, porém com dimensões muito maiores.

Uma característica distintiva do CEE1 é sua sensibilidade à fase do jogo, dividindo a partida em três períodos baseados no número de casas vazias. A abertura é definida como períodos com mais de 22 casas vazias (correspondendo aproximadamente aos primeiros turnos), o meio-jogo como períodos com entre 11 e 22 vazias, e o final como períodos com até 10 casas vazias.

Para cada fase, o avaliador emprega um compositor distinto, permitindo que a importância relativa dos fatores seja ajustada conforme o estágio da partida evolui. Durante a abertura, posições e mobilidade assumem maior importância relativa, com pesos de 0.4 para posicional, 0.2 para material e 0.2 para fronteira. No meio-jogo, material e posição tornam-se mais balanceados, com 0.3 para posicional, 0.4 para material e 0.2 para fronteira. No final, material domina com peso 0.7, enquanto posicional e fronteira contribuem modestamente com 0.2 e 0.1 respectivamente.

A ativação de apenas um compositor por vez, determinado pela fase atual, evita conflitos entre avaliações de diferentes períodos da partida. Quando a partida transita de uma fase para outra, a weights de avaliação muda gradualmente, refletindo a evolução natural das prioridades estratégicas.

### 4.7 Avaliadores Ajustados por Aprendizado de Máquina

Os avaliadores ajustados representam uma abordagem empiricamente fundamentada para otimização de heurísticas, utilizando técnicas de aprendizado de máquina para determinar pesos ótimos a partir de dados observacionais. Em vez de depender de valores intuitivos definidos manualmente, esses avaliadores aprendem suas configurações a partir de partidas reais, capturando padrões que podem não ser imediatamente óbvios para designers humanos.

O processo de treinamento emprega uma base de 600 jogos disputados entre agentes MCTS com 10.000 iterações cada. Essa escolha de agentes para gerar dados de treinamento é deliberada: o MCTS representa uma política de jogo forte mas não perfeita, gerando situações de jogo variadas e realistas sem introduzir vieses sistemáticos que pudessem distorcer o aprendizado.

Dois tipos de ajuste foram realizados, cada um otimizando um objetivo distinto. O ajuste para vitória (WIN), implementado através de regressão logística, busca encontrar pesos que maximizem a probabilidade de vitória do avaliador. A regressão logística modela a relação entre os parâmetros do avaliador e a probabilidade binária de vitória, produzindo um modelo onde a saída pode ser interpretada como a chance de o jogador das brancas vencer a partida.

O ajuste para pontuação (SCORE), implementado através de regressão linear, busca encontrar pesos que maximizem a diferença final de peças entre os jogadores. Diferentemente do WIN, que otimiza puramente para vitória, o SCORE considera também a margem de vitória, penalizando vitórias apertadas e recompensando vitórias consolidadas.

Os avaliadores CWTE1 e WWTE1 foram obtidos através do ajuste WIN. Os avaliadores CSTE1 e WSTE1 foram obtidos através do ajuste SCORE. A diferença nos prefixos (CW versus CS, WW versus WS) indica se o treinamento foi realizado sobre a variante clássica (C) ou a variante circular (W).

Os pesos aprendidos são completamente diferentes dos pesos padrão, revelando estratégias otimizadas empiricamente que podem diferir significativamente da sabedoria convencional. Por exemplo, alguns pesos aprendidos podem supervalorizar certas regiões do tabuleiro que, embora aparentemente perigosas na teoria clássica, podem oferecer vantagens em contextos específicos que emergem dos padrões de jogo observados.

Uma característica importante dos pesos aprendidos é que eles são ajustados independentemente para cada fase do jogo (abertura, meio-jogo, final), permitindo que estratégias completamente diferentes sejam preferidas conforme a partida progride. Isso reflete a observação de que fatores importantes no início do jogo frequentemente tornam-se irrelevantes ou até contraproducentes no final, e vice-versa.

---

## 5. A Variante Othello Circular (WrapAround)

### 5.1 Motivação e Descrição da Regra

A variante Othello Circular foi introduzida neste estudo para investigar como a modificação de propriedades topológicas fundamentais do jogo afeta as estratégias óptimas e o desempenho relativo dos algoritmos. A regra clássica de captura no Othello determina que linhas de visão são limitadas pela borda física do tabuleiro: ao atravessar uma borda sem encontrar uma peça do próprio jogador, a captura naquela direção não se concretiza. A variante circular remove essa limitação para peças posicionadas sobre as diagonais principais.

Formalmente, uma casa é considerada estar sobre uma diagonal principal se satisfizer uma de duas condições: a coluna é igual à linha (diagonal principal) ou a coluna é igual ao tamanho do tabuleiro menos um menos a linha (diagonal secundária). No tabuleiro 6×6, essas condições identificam as casas (0,0), (1,1), (2,2), (3,3), (4,4), (5,5) para a diagonal principal, e (0,5), (1,4), (2,3), (3,2), (4,1), (5,0) para a diagonal secundária.

Quando uma peça está posicionada sobre uma dessas diagonais, qualquer linha de visão que atravesse a borda do tabuleiro nessa direção "emerge" do lado oposto, continuando a busca por peças flanqueáveis. A emergência ocorre preservando a direção do movimento: ao sair pela borda superior, a linha reaparece na borda inferior; ao sair pela borda direita, reaparece na esquerda; e as combinações diagonais preservam seus componentes vertical e horizontal.

Essa conexão periódica transforma fundamentalmente a geometria do jogo. Uma peça em um canto, que no Othello tradicional possui apenas três direções de captura limitadas, passa a enxergar casas em todas as direções exceto aquelas estritamente paralelas às diagonais onde reside. No caso dos cantos (0,0) e (5,5), que estão sobre a diagonal principal, e (0,5) e (5,0), que estão sobre a diagonal secundária, essas peças adquirem linhas de visão que atravessam o tabuleiro diagonalmente.

### 5.2 Representação Visual e Exemplo de Captura

A configuração inicial da variante circular, com peças nos cantos, já antecipa o papel estratégico especial dessas posições. Diferentemente do jogo clássico onde os cantos representam pontos de segurança máxima, na variante circular os cantos são precisamente as posições que ativam o mecanismo de wraparound.

```
   0   1   2   3   4   5
0  W   .   .   .   .   W    <-- Brancas sobre diagonal secundária
1  .   .   .   .   .   .    <-- Linhas diagonais passam por (0,0)
2  .   .   .   .   .   .    <-- Diagonal secundária: (0,5),(1,4),(2,3),(3,2),(4,1),(5,0)
3  .   .   .   .   .   .    <-- Diagonal secundária: (0,5),(1,4),(2,3),(3,2),(4,1),(5,0)
4  .   .   .   .   .   .    <-- Diagonal secundária: (0,5),(1,4),(2,3),(3,2),(4,1),(5,0)
5  B   .   .   .   .   B    <-- Pretas sobre diagonal secundária

   0   1   2   3   4   5
0  W   .   .   .   .   W    <-- Brancas sobre diagonal principal
1  .   .   .   .   .   .    <-- Diagonal principal: (0,0),(1,1),(2,2),(3,3),(4,4),(5,5)
2  .   .   .   .   .   .    <-- Diagonal principal: (0,0),(1,1),(2,2),(3,3),(4,4),(5,5)
3  .   .   .   .   .   .    <-- Diagonal principal: (0,0),(1,1),(2,2),(3,3),(4,4),(5,5)
4  .   .   .   .   .   .    <-- Diagonal principal: (0,0),(1,1),(2,2),(3,3),(4,4),(5,5)
5  B   .   .   .   .   B    <-- Pretas sobre diagonal principal
```

Para ilustrar o mecanismo de captura circular, considere o seguinte cenário. Uma peça branca no canto superior esquerdo (0,0) está sobre a diagonal principal. Se houver uma sequência de peças pretas ao longo da diagonal na direção nordeste (incrementando linha e coluna), essas peças poderiam ser capturadas através de um movimento na direção oposta (sudoeste). No jogo clássico, a busca nessa direção pararia na borda esquerda do tabuleiro; na variante circular, a busca "emerge" na borda direita e continua até encontrar uma casa válida.

```
Exemplo de captura circular partindo de (0,0):

Sentido da captura (sudoeste): (0,0) -> wrapping para (5,5) -> (5,4) -> (4,3) -> ...

Se (5,5) é preta, (4,4) é preta, e (3,3) é preta, e (2,2) é branca,
então jogar (0,0) capturaria as três pretas em (5,5), (4,4) e (3,3).

   0   1   2   3   4   5
0  W ← ← ← ← ← ← ← ←   <-- Direção "emergente"
1  .   .   .   .   .   .
2  B ← ← ← ← ← ← ← ←   <-- (2,2) capturada (era preta, está entre brancas)
3  B ← ← ← ← ← ← ← ←   <-- (3,3) capturada
4  B ← ← ← ← ← ← ← ←   <-- (4,4) capturada
5  B ← ← ← ← ← ← ← ←   <-- (5,5) capturada
```

### 5.3 Implicações Estratégicas

A introdução de linhas de captura circulares transforma fundamentalmente o panorama estratégico do Othello. Muitas das heurísticas que guiam jogadores experientes no jogo tradicional perdem relevância, enquanto novas considerações emergem.

Os cantos, tradicionalmente posições de segurança absoluta, perdem essa propriedade na variante circular. Uma peça branca no canto superior esquerdo pode ser flanqueada através de uma captura que emerge na borda oposta do tabuleiro. Isso significa que o controle de cantos não garante segurança permanente, alterando fundamentalmente o calculus de decisões táticas envolvendo essas posições.

Estratégias de controle de bordas também se tornam menos relevantes. No jogo tradicional, ocupar posições nas bordas oferece vantagens porque limitam as opções de flanqueamento do oponente. Na variante circular, as bordas são "transparentes" para peças sobre diagonais, permitindo linhas de captura que contornam as limitações tradicionais.

A importância posicional se redistribui geograficamente. Casas sobre as diagonais ganham valor estratégico adicional, pois oferecem linhas de visão mais extensas. Simultaneamente, casas diretamente adjacentes às diagonais podem se tornar mais vulneráveis, pois estão expostas a capturas circulares.

A mecânica de wraparound também introduz possibilidades táticas únicas, como capturar peças que parecem estar protegidos por barreiras de peças próprias. Uma sequência de capturas pode teoricamente "dar a volta" no tabuleiro, flanqueando peças que estavam aparentemente seguras atrás de linhas defensivas.

Essas transformações têm implicações diretas para o design de avaliadores. Avaliadores treinados no jogo clássico podem não transferir efetivamente para a variante circular, explicando a necessidade de avaliadores específicos (WWTE1 e WSTE1) com pesos otimizados para esse contexto.

---

## 6. Metodologia de Análise

### 6.1 Resumo Estatístico

A análise de resumo estatístico fornece uma visão consolidada do volume e características das partidas coletadas durante os experimentos. O resumo incluye o número total de partidas simuladas, o total de turnos executados (jogadas individuais), e o tempo total despendido em decisões de jogada pelos agentes. Essas métricas fundamentales estabelecem o contexto quantitativo para todas as análises subsequentes.

O desempenho por confronto constitui uma dimensão crítica do resumo, sempre reportado da perspectiva do jogador preto. Para cada pareamento específico entre agentes (determinado pelo tipo de avaliador do Minimax, profundidade, e iterações do MCTS), são computadas estatísticas de vitória, derrota, empate e taxa de vitória para o jogador preto. Essa organização permite identificar quais configurações favorecem mais consistentemente um lado, revelando potenciais assimetrias nos algoritmos ou nos avaliadores.

A apresentação do resumo inclui seções separadas para cada pareamento único, permitindo comparação direta entre configurações. A taxa de vitória, expressa como percentual, oferece uma métrica agregada que resume o resultado líquido de múltiplas partidas, embora perda informação sobre a distribuição de margens de vitória.

### 6.2 Mapa de Calor de Vitória

O mapa de calor de vitória representa graficamente as taxas de vitória do Minimax contra o MCTS em função de dois parâmetros: a profundidade de busca do Minimax (eixo vertical) e o número de iterações do MCTS (eixo horizontal). Cada célula do mapa exibe a taxa de vitória do Minimax, em percentual, na combinação correspondente de parâmetros.

A análise através de mapas de calor revela zonas de domínio entre os algoritmos. Regiões onde o Minimax apresenta taxas de vitória consistentemente altas indicam configurações onde a profundidade de busca é suficiente para superar as estimativas estatísticas do MCTS. Regiões onde o MCTS domina revelam situações onde o número de iterações disponíveis para o MCTS é достаточным para superar as limitações da heurística empregada pelo Minimax.

Três variantes do mapa são geradas para cada avaliador do Minimax: uma quando o Minimax joga com peças brancas, uma quando joga com peças pretas, e uma agregando ambos os casos. A separação por cor inicial permite investigar se existem assimetrias no desempenho relacionadas à ordem de jogo. Diferenças significativas entre os mapas de diferentes cores podem indicar que a heurística está mais bem calibrada para um lado ou que o tabuleiro inicial favorece estruturalmente um dos jogadores.

### 6.3 Tempo Médio do Minimax

A análise de tempo médio por jogada do Minimax examina como o custo computacional evoluciona com o aumento da profundidade de busca. O gráfico resultante apresenta a profundidade no eixo horizontal e o tempo médio (em segundos) no eixo vertical, com múltiplas séries correspondendo a diferentes avaliadores.

O padrão típico de crescimento é aproximadamente exponencial com a profundidade, refletindo o aumento no número de nós explorados na árvore de jogo. A taxa específica de crescimento depende criticamente da eficácia da poda alfa-beta e da branching factor em diferentes fases do jogo. Avaliadores que produzem ordenações de movimentos mais próximas da ótima tendem a permitir poda mais agressiva, resultando em tempos menores para a mesma profundidade.

A comparação entre avaliadores revela diferenças práticas significativas. Um avaliador que produz decisões marginalmente melhores mas requer três vezes mais tempo pode ser menos interessante em aplicações com restrições temporais. Os gráficos permitem identificar o ponto de saturação onde aumentar a profundidade oferece retornos decrescentes em relação ao custo computacional adicional.

### 6.4 Tempo Médio do MCTS

A análise de tempo médio do MCTS investiga a escalabilidade temporal do algoritmo em função do número de iterações. O gráfico apresenta iterações no eixo horizontal e tempo médio no eixo vertical, com uma curva crescente que reflete o custo linearmente proporcional ao número de iterações.

Diferentemente do Minimax, onde o tempo pode variar drasticamente conforme a eficácia da poda, o MCTS apresenta um padrão de crescimento mais regular. Cada iteração requer processamento aproximadamente constante, resultando em uma relação tempo-iterações que é aproximadamente linear. Variações em torno dessa linearidade podem refletir características do estado do jogo (por exemplo, estados com menos movimentos legais permitem iterações mais rápidas).

A análise permite selecionar o número de iterações adequado para diferentes budgets temporais. Em contextos onde milliseconds importam (como partidas blitz), iterações menores podem ser preferíveis. Em contextos com tempo ilimitado, o analista pode identificar o ponto onde o aumento de iterações oferece melhorias negligíveis na qualidade da decisão.

### 6.5 Tempo Médio por Turno

A análise de tempo médio por turno revela como o custo computacional varia ao longo da progressão da partida. O gráfico apresenta o número do turno no eixo horizontal e o tempo médio por jogada no eixo vertical, com múltiplas séries correspondendo a diferentes configurações de agentes.

Padões distintos emergem para Minimax e MCTS. O Minimax frequentemente apresenta maior custo computacional no meio-jogo, quando o número de movimentos legais é máximo e a árvore de busca é mais ramificada. No final do jogo, com menos casas vazias, o Minimax explora menos estados por decisão. O MCTS pode apresentar padrão diferente, onde o custo por iteração permanece relativamente estável mas a qualidade das simulações (e portanto o número de iterações necessárias) pode variar com a fase.

A identificação de fases problematicas — turnos onde um agente consistentemente requer tempo desproporcional — oferece oportunidades para otimização. Por exemplo, técnicas de aspiração de poda podem ser aplicadas ao Minimax quando o tempo por turno excede thresholds predeterminados.

### 6.6 Estados Explorados pelo Minimax

A análise de estados explorados mede o volume total de nós avaliados pelo Minimax ao longo de uma partida, ou como média por profundidade. O gráfico apresenta a profundidade no eixo horizontal e o número acumulado de estados explorados no eixo vertical, com múltiplas séries para diferentes avaliadores.

O crescimento do número de estados com a profundidade reflete a exponencialidade inerente à busca em árvore. Um avaliador que permite melhor ordenação de movimentos (aproximando os melhores movimentos do topo da lista) possibilita poda mais eficaz, explorando menos estados para alcançar a mesma profundidade. A comparação entre avaliadores nesse eixo revela a eficiência prática de diferentes heurísticas.

A análise também permite verificar se o número de estados explorados se correlaciona com o desempenho do agente. Em alguns casos, avaliadores que geram mais estados podem produzir decisões superiores, justificando o custo computacional adicional. Em outros casos, a relação pode ser inversa, sugerindo que menos estados explorados com melhores heurísticas podem superar muitas simulações com heurísticas pobres.

### 6.7 Estados Explorados versus Podados

A análise de estados explorados versus podados investiga a eficácia da poda alfa-beta em diferentes níveis da árvore de busca. A visualização emprega barras empilhadas para cada profundidade, mostrando a proporção de estados explorados versus podados naquele nível.

Uma barra predominantemente azul (representando estados explorados) indica que pouca poda occurred naquela profundidade, sugerindo que a ordenação de movimentos está próxima da aleatória ou que os valores dos nós são muito similares. Uma barra com proporção significativa de estados podados indica eficácia da otimização.

A evolução da eficácia de poda através dos níveis revela onde o Minimax mais se beneficia da otimização. Tipicamente, a poda é mais eficaz em profundidades intermediárias, onde a árvore ainda possui largura significativa mas os valores de corte estão mais estabelecidos. Nos níveis próximos à raiz, a poda é limitada pelo pequeno número de filhos; nos níveis folha, não há poda por definição.

### 6.8 Mapa de Calor de Posicionamento

O mapa de calor de posicionamento revela as preferências espaciais dos agentes, indicando com que frequência cada casa do tabuleiro é escolhida para posicionamento de peças. A visualização apresenta o tabuleiro 6×6 com intensidades de cor correspondendo à frequência absoluta de escolhas em cada posição.

A análise permite identificar padrões estratégicos distintivos. Agentes que consistentemente evitam casas específicas (evidenciado por baixa frequência) revelam que essas posições são consideradas desfavoráveis pela heurística. Inversamente, casas com alta frequência indicam posições valorizadas pelo agente.

Três variantes do mapa são geradas: quando o agente joga com peças brancas, quando joga com peças pretas, e agregando ambos os casos. A diferença entre os mapas de diferentes cores pode revelar assimetrias na estratégia conforme a perspectiva do jogador.

Para o Minimax, os mapas de posicionamento refletem diretamente os pesos da função de avaliação. Avaliadores que valorizam cantos mostrarão alta frequência nesses posições. Para o MCTS, os padrões emergem do resultado das simulações, potencialmente revelando estratégias que não seriam intuitivamente óbvias.

### 6.9 Mapa de Calor de Captura

O mapa de calor de captura complementa a análise de posicionamento ao revelar onde os agentes convertem peças do oponente. Cada casa do tabuleiro é colorida de acordo com a frequência com que peças nela foram capturadas durante as decisões do agente.

Regiões de alta captura indicam onde o agente é mais eficaz em converter peças adversárias. Isso pode refletir tanto a estratégia ativa do agente (escolhendo jogadas que capturam em posições específicas) quanto a vulnerabilidade do oponente (forçando capturas em certas regiões).

A comparação entre mapas de captura de diferentes agentes revela diferenças táticas. Um agente pode preferir capturas conservadoras em regiões seguras, enquanto outro pode visar capturas agressivas em regiões de maior risco. A análise também pode identificar padrões relacionados à fase do jogo, onde a localização das capturas evolui conforme o tabuleiro se preenche.

---

## 7. Considerações Finais

### 7.1 Síntese das Contribuições

Este trabalho apresentou uma investigação sistemática sobre a comparação entre os paradigmas Minimax e Monte Carlo Tree Search aplicados ao jogo Othello, com extensão para a variante circular (WrapAround). A metodologia empregada, baseada em confrontos extensivos com múltiplas configurações de parâmetros, permitiu extrair insights sobre os trade-offs fundamentais entre as duas abordagens.

A análise detalhada das seis funções de avaliação (SCE1, CEE1, CWTE1, CSTE1, WWTE1, WSTE1) demonstrou que a escolha da heurística influencia significativamente o desempenho do Minimax. Os avaliadores ajustados por aprendizado de máquina, treinados através de regressão logística e regressão linear sobre bases de jogos MCTS, produziram configurações de pesos que diferem fundamentalmente dos valores intuitivos classicamente propostos. Essa observação sugere que a sabedoria convencional sobre valores posicionais no Othello pode beneficiar-se de refinamento empírico.

A documentação das métricas de desempenho — incluindo tempos de decisão, estados explorados, estados podados, e padrões de posicionamento e captura — fornece um panorama abrangente do comportamento dos agentes. Os mapas de calor de vitória revelaram zonas de domínio onde cada paradigma apresenta vantagens, oferecendo guidance para a seleção de algoritmos conforme o contexto específico de aplicação.

A introdução e análise da variante circular demonstraram como modificações topológicas fundamentais afetam as estratégias óptimas. A necessidade de avaliadores específicos para essa variante (WWTE1 e WSTE1) confirma que conhecimento adaptado ao contexto é essencial para desempenho próximo do óptimo.

### 7.2 Limitações do Estudo

Reconhecer as limitações de uma investigação é essencial para interpretar corretamente seus resultados e identificar direções para trabalho futuro. Este estudo apresenta diversas limitações que devem ser consideradas.

O tabuleiro de dimensões 6×6, embora permita experimentos viáveis computacionalmente, difere significativamente do Othello padrão 8×8. As propriedades estratégicas do jogo em dimensões reduzidas podem não transferir diretamente para o tabuleiro completo, onde a profundidade da busca e o branching factor assumem valores muito maiores.

Os ranges de parâmetros explorados, embora abrangentes dentro das restrições computacionais, representam subespaços do espaço total de configurações possíveis. Profundidades maiores que sete camadas, iterações maiores que 25.000, e avaliadores com arquiteturas alternativas não foram examinados, deixando espaço para comportamentos não observados.

A geração de dados de treinamento para os avaliadores ajustados baseou-se exclusivamente em agentes MCTS. Embora essa escolha seja deliberada, ela introduz um viés que pode não representar adequadamente estratégias Minimax. Avaliadores treinados em jogos Minimax versus Minimax poderiam produzir configurações de pesos ainda diferentes.

Os experimentos foram conduzidos em condições controladas com tempo de decisão ilimitado. Aplicações práticas frequentemente impõem restrições temporais que podem favorecer algoritmos com melhor escalabilidade em detrimento daqueles com pico de desempenho superior.

### 7.3 Possíveis Extensões

O trabalho abre diversas avenidas para investigação futura que podem estender e aprofundar os insights obtidos. A primeira e mais direta extensão seria reproduzir os experimentos no tabuleiro 8×8 padrão do Othello, permitindo comparação direta com a literatura existente e avaliação da transferência de resultados entre dimensões.

A exploração de arquiteturas de avaliadores alternativas representa outra direção promissora. Redes neurais profundas, como arquiteturas convolucionais que processam diretamente a representação do tabuleiro, poderiam aprender padrões posicionais que escapam às heurísticas baseadas em regiões discretas. A combinação de avaliação neural com busca Minimax ou MCTS poderia produzir agentes de desempenho superior.

A investigação de avaliadores treinados de forma adversarial, onde geram dados a partir de jogos Minimax versus Minimax em vez de MCTS versus MCTS, permitiria avaliar se os pesos aprendidos são específicos ao oponente ou generalizam entre paradigmas. Experimentos de transferência, onde avaliadores treinados em um paradigma são testados contra o outro, forneceriam insights sobre a generalidade das heurísticas aprendidas.

A análise de variantes adicionais do Othello além da circular proposta neste trabalho representa outra direção interessante. Variantes com dimensões assimétricas, restrições adicionais de captura, ou regras especiais de final de jogo poderiam revelar propriedades fundamentais dos algoritmos que não emergem no jogo tradicional.

Finalmente, a aplicação dos insights obtidos a outros domínios de jogos bipartidários completaria o ciclo de generalização. Domain onde as técnicas se transferem efetivamente (como jogos de captura territorial com mecânicas similares) e onde falham (revelando limitações da abordagem) ajudariam a delimitar o escopo de aplicabilidade dos métodos estudados.

---

## Referências

O desenvolvimento deste trabalho fundamentou-se em princípios estabelecidos na literatura de jogos algorítmicos e inteligência artificial. Os algoritmos Minimax e suas otimizações, incluindo a poda alfa-beta, têm raízes nos trabalhos fundacionais de Shannon sobre programas de xadrez. O algoritmo Monte Carlo Tree Search emergiu de pesquisas em planejamento automatizado e alcançou prominence após sua aplicação bem-sucedida a jogos de Go.

A aplicação de aprendizado de máquina para ajuste de heurísticas representa uma convergência entre técnicas clássicas de IA e métodos modernos de otimização. A regressão logística e a regressão linear, embora tecnicamente simples, demonstraram eficácia na descoberta de configurações de pesos que superam designs manuais em diversos domínios experimentados.

---

*Este artigo foi elaborado como documentação técnica e acadêmica do projeto de comparação entre agentes Minimax e MCTS em Othello.*
