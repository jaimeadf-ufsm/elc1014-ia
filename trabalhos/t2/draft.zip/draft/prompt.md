# Prompt para Escrita do Artigo

## 1. Estrutura do Artigo

1. Introdução
2. Objetivos
3. Othello
   - 3.1 Variante Circular
4. Agentes
   - 4.1 MCTS
   - 4.2 Minimax
5. Funções de Avaliação (Heurísticas)
   - 5.1 Heurística de Material
   - 5.2 Heurística de Posição
   - 5.3 Heurística de Mobilidade Potencial
   - 5.4 Heurística de Paridade
   - 5.5 Composição de Heurísticas
   - 5.6 Definição dos Avaliadores
     - Nota: Você deve definir todos os avaliadores (SCE1, CEE1, CSTE1, CWTE1, WWTE1, WSTE1), discutir como são a estrutura deles (isto é, quais subavaliadores eles usam) e como foram escolhidos os seus pesos. Busque informações nas seções abaixo ou nos arquivos.
6. Análise Experimental
7. Resultados e Discussão
   - 7.1 Variante Clássica
     - 7.1.1 Taxas de vitória
     - 7.1.2 Impacto do parâmetros
     - 7.1.3 Eficácia da poda alfa-beta
     - 7.1.4 Mapas de capturas e jogadas
   - 7.2 Variante Circular
     - 7.2.1 Taxas de vitória
     - 7.2.2 Mapas de capturas e jogadas
8. Considerações Finais

## 2. Regras de Escrita

- Escreva majoritariamente em **parágrafos corridos e longos** em português brasileiro
- Use linguagem **formal e acadêmica**
- Escreva **mais de um parágrafo por seção** quando necessário
- Use **enumerações, tabelas ou itemizações** quando realmente ajudar a compreensão
- **Pense e compreenda** os resultados e análises para criar observações e discuti-las
- Inclua **legendas em todas as figuras** e **referencie-as no texto**
- Para cada seção, pense nas imagens e como ela se relaciona com as anteriores

## 3. Observações sobre Resultados

### Variante Clássica
- **Total**: 9408 partidas, 307277 turnos, ~118 horas de simulação
- **SCE1**: 0% de taxa de vitória em todas as combinações. Não é boa heurística
- **CEE1**: Taxa de vitória variou pouco (até 41%). Escolhas aleatórias do MCTS explicam variação
- **CSTE1**: Profundidade 5 alcançou 61% contra MCTS(2500). Profundidade 6 alcançou 76% contra MCTS(2500) jogando de brancas
- **CWTE1**: Excelente desempenho ao jogar de pretas, alcançando 88% contra MCTS(10000). Regressão logística melhorou a heurística

### Variante Circular
- **Total**: 5726 partidas, 183971 turnos, ~84 horas de simulação
- **SCE1**: Conseguiu algumas vitórias jogando de pretas, mas não de brancas
- **CWTE1**: Treinado na variante clássica, alcançou 100% de vitória nas profundidades 4 e 6 de pretas. Resultados parecem aleatórios de brancas
- **WWTE1**: Treinado na variante circular, alcançou 100% de vitória na profundidade 6 de pretas, 60% de brancas

### Análise Geral
- MCTS mantém tempo constante, Minimax gasta mais tempo nos primeiros turnos
- Crescimento exponencial de estados explorados com profundidade
- Proporção de poda aumenta em profundidades maiores
- MCTS evita cantos C, prefere cantos Q
- Na variante circular, diagonais são posições mais disputadas (diferente da clássica)

## 4. Detalhamento dos Avaliadores (Código)

### SCE1
```python
SIMPLE_COUNT_EVALUATOR = CountEvaluator(name='SCE1')
```
- Avaliador simples de contagem de peças
- Apenas a diferença entre peças brancas e pretas

### CEE1
```python
CLASSICAL_EMPIRIC_EVALUATOR = PhaseAwareEvaluator(
    opening=CompositeEvaluator([
        PositionalEvaluator(scale=0.4),
        CountEvaluator(scale=0.2),
        PotentialMobilityEvaluator(scale=0.2)
    ]),
    midgame=CompositeEvaluator([
        PositionalEvaluator(scale=0.3),
        CountEvaluator(scale=0.4),
        PotentialMobilityEvaluator(scale=0.2)
    ]),
    endgame=CompositeEvaluator([
        CountEvaluator(scale=0.7),
        CountEvaluator(scale=0.2),
        PotentialMobilityEvaluator(scale=0.1)
    ]),
    name='CEE1'
)
```
- Pesos escolhidos empiricamente
- Não inclui ParityEvaluator

### CSTE1
```python
CLASSICAL_SCORE_TUNED_EVALUATOR = PhaseAwareEvaluator(
    CompositeEvaluator([...]),  # opening
    CompositeEvaluator([...]),  # midgame
    CompositeEvaluator([...]),  # endgame
    name='CSTE1'
)
```
- Treinado com regressão linear para prever pontuação final
- Todas as fases usam CountEvaluator, PositionalEvaluator, PotentialMobilityEvaluator e ParityEvaluator

### CWTE1
```python
CLASSICAL_WIN_TUNED_EVALUATOR = PhaseAwareEvaluator(
    CompositeEvaluator([...]),  # opening
    CompositeEvaluator([...]),  # midgame
    CompositeEvaluator([...]),  # endgame
    name='CWTE1'
)
```
- Treinado com regressão logística para prever vitória
- Todas as fases usam CountEvaluator, PositionalEvaluator, PotentialMobilityEvaluator e ParityEvaluator

### WWTE1
```python
WRAP_AROUND_WIN_TUNED_EVALUATOR = PhaseAwareEvaluator(
    CompositeEvaluator([...]),  # opening
    CompositeEvaluator([...]),  # midgame
    CompositeEvaluator([...]),  # endgame
    name='WWTE1'
)
```
- Treinado com regressão logística na variante circular
- Mesma estrutura de avaliadores que CWTE1

### WSTE1
```python
WRAP_AROUND_SCORE_TUNED_EVALUATOR = PhaseAwareEvaluator(
    CompositeEvaluator([...]),  # opening
    CompositeEvaluator([...]),  # midgame
    CompositeEvaluator([...]),  # endgame
    name='WSTE1'
)
```
- Treinado com regressão linear na variante circular
- Mesma estrutura de avaliadores que CSTE1

## 5. Notas Importantes

- Cada avaliador retorna parâmetros multiplicados pelos pesos
- O avaliador composto (CompositeEvaluator) concatena parâmetros e pesos dos avaliadores componentes
- O avaliador sensível a fase (PhaseAwareEvaluator) muda a avaliação conforme a fase do jogo:
  - Abertura: mais de 22 casas vazias
  - Meio-jogo: entre 11 e 22 casas vazias
  - Final: até 10 casas vazias
- O CSTE1 e o CWTE1 foram ajustadas com um dataset criado com:
  - MCTS com 10000 iteracoes contra MCTS com 10000 interacoes
  - 0 a 7 movimentos aleatorios antes do MCTS
  - 700 partidas (377 brancas, 281 pretas e 42 empates)
  - 20065 movimentos
  - Aproxidamente 57 horas de simulação
- O WSTE1 e o WSTE1 foram ajustado com um datasat criado com:
  - MCTS com 5000 iteracoes contra MCTS com 5000 interacoes
  - (1305 pretas, 1226 brancas, 169 empates)
  - 76975 movimentos
  - aproximadamente 104 horas de simulação

## 6. Sugestões de Melhoria

- Caso precisar de alguma informação, dado, diagrama, coloque um X no lugar, para que depois seja completado.