Estou elaborando a estrutura no arquivo estrutura.md do trabalho especificado em trabalho.md para que um agente possa realizar a escrita depois em Markdown. O arquivo figuras.txt descreve todas as imagens que devem aparecer no trabalho. Separe as observações de dentro da estrutura e descreva em outro lugar para que o agente possa compreender. Crie o prompt completo que deve ser enviado ao agente em Markdown. O prompt deve ser relativamente simples com a estrutura numerada, as ordens e os contextos que estão atualmente misturado. Evite sair muito dessa estrutura, mas fique a vontade para sugerir melhorias. No arquivo geral.md e pipelines.md tem a visão geral do que foi implementando no trabalho. O prompt deve ser simples para que o agente possa fazer sua propria busca e escrita, sem algo engessado.

Você só deve criar o arquivo prompt.md. Prompt simples, somente com instruções, inspirado neste.

O artigo deve incluir:
- A explicação completa de todas os avaliadores utilizados (SCE1, CEE1, CSTE1, CWTE1, WWTE1 e CWTE1). Inclua os código utilizados para a definição dos avaliadores, pois é mais fácil de entender com a composição ocorre.

O agente deve ser guiado para:
- Escrever majoritariamente em parágrafos corridos e longos em português brasileiro. Linguagem formal e acadêmica.
- Escrever mais de um parágrafo por seção, quando necessário, utiliza itemizações, enumerações ou tabelas quando for melhor.
- Pensar e compreender os resultados e as análises para criar observações e realmente os discutir. 
- Incluir legendas em todas as figuras e referencia-las n otexto
- Para cada seção, pense nas imagens e como a seção se relaciona com as anterires.
