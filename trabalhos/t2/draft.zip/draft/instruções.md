
## 1. Identificação do Projeto

**Título:** Comparação de Agentes de Busca em Othello: Minimax vs MCTS

**Variante estudada:** Othello Circular (WrapAround)

**Linguagem:** Português brasileiro | Texto acadêmico e formal | Parágrafos corridos

---

## 2. Arquivos de Referência

O agente deve compreender os arquivos do projeto.

## 3. Regras de Escrita

O agente **DEVE** seguir rigorosamente as seguintes regras:

1. **Texto corrido como padrão:** Todas as explicações devem ser feitas em parágrafos fluidos. Listas e enumerações só devem ser usadas quando absolutamente necessário.

2. **Foco em conceitos, não em código:** O agente **NÃO DEVE** citar nomes de classes de implementação (como `MinimaxPlayer`, `MCTSPlayer`, `CompositeEvaluator`, etc.). Deve descrever os conceitos e mecanismos em linguagem natural.

3. **Nomenclatura dos avaliadores:** O agente deve usar os nomes conforme definidos no código:

   | Nome no Código | Descrição |
   |----------------|-----------|
   | `SCE1` | Simple Count Evaluator 1 — Avaliador de Contagem Simples |
   | `CEE1` | Classical Empiric Evaluator 1 — Avaliador Empírico Clássico |
   | `CWTE1` | Classical Win Tuned Evaluator 1 — Avaliador Ajustado por Vitória (Regressão Logística) |
   | `CSTE1` | Classical Score Tuned Evaluator 1 — Avaliador Ajustado por Pontuação (Regressão Linear) |
   | `WWTE1` | WrapAround Win Tuned Evaluator 1 — Avaliador Ajustado por Vitória na variante Circular |
   | `WSTE1` | WrapAround Score Tuned Evaluator 1 — Avaliador Ajustado por Pontuação na variante Circular |

4. **Explicação dos pesos:** O artigo deve explicar claramente que os pesos são aprendidos de forma **independente** para cada cor (brancas e pretas), permitindo que o modelo capture estratégias assimétricas onde cada lado pode ter importâncias diferentes para cada fator avaliado.

5. **Portugal brasileiro:** Todos os termos técnicos devem ser traduzidos ou adaptados para português brasileiro. Termos como "avaliador" (evaluator), "profundidade" (depth), "iterações" (iterations), "pesos" (weights), "parâmetros" (params), "mobilidade" (mobility), "paridade" (parity), etc., devem ser usados consistentemente.

---

## 4. Fluxo de Trabalho

O agente **DEVE** seguir esta sequência:

1. **Ler e compreender** todos os arquivos de referência fornecidos
2. **Gerar um plano** de seções e subseções (em texto corrido) e enviar para aprovação
3. **Aguardar aprovação** antes de prosseguir
4. **Escrever o artigo** seguindo as seções aprovadas
5. **Revisar** para garantir consistência e qualidade

---

## 5. Esqueleto de Seções Proposto

O agente **NÃO** deve considerar esta estrutura como fixa. Ele **DEVE** sentir-se livre para criar mais seções e subseções conforme necessário, desde que mantenham o foco nos conceitos e na coerência narrativa.

### 5.1 Seções Obrigatórias

1. **Introdução**
   - Contextualização do problema
   - Objetivos do trabalho
   - Relevância da comparação Minimax × MCTS

2. **O Jogo Othello e suas Regras**
   - Descrição do tabuleiro 6×6
   - Posicionamento inicial das peças
   - Regras de captura
   - Condição de vitória e final de jogo

3. **Arquitetura dos Agentes de Jogo**
   - O algoritmo Minimax com poda alfa-beta
     - Profundidade de busca como parâmetro
     - Eficiência da poda e estados explorados
   - O algoritmo Monte Carlo Tree Search
     - Mecanismo de seleção e simulação
     - Número de iterações como parâmetro

4. **Funções de Avaliação (Heurísticas)**
   - Princípio da avaliação posicional
     - Sistema de pesos: explicação detalhada de como funcionam os vetores de pesos
     - Por que existem pesos separados para peças brancas e pretas em cada avaliador?
     - Como a combinação de pesos gera a pontuação final?
   - Avaliador de Material (SCE1)
     - Contagem de peças como métrica básica
     - Parâmetros calculados
   - Avaliador Posicional
     - Mapeamento das seis regiões estratégicas do tabuleiro
     - Valores atribuídos a cada região
     - Por que cantos e casas adjacentes têm pesos diferentes?
   - Avaliador de Mobilidade Potencial (Fronteira)
     - Conceito de peças na fronteira
     - Como mede a exposição de cada lado
   - Avaliador de Paridade
     - Vantagem do último movimento
     - Relação entre peças vazias e turno atual
   - Avaliador Compositor (CEE1)
     - Combinação de múltiplos avaliadores
     - Comportamento sensível à fase do jogo (abertura, meio-jogo, final)
   - Avaliadores Ajustados por Aprendizado de Máquina
     - Processo de treinamento com 600 jogos MCTS×MCTS (10.000 iterações)
     - Ajuste WIN (regressão logística): otimização para maximizar vitórias
     - Ajuste SCORE (regressão linear): otimização para maximizar diferença de peças
     - Representação dos pesos ajustados e sua interpretação

5. **A Variante Othello Circular**
   - Descrição da regra de captura periódica
   - Representação visual do tabuleiro inicial
   - Impacto estratégico: mudanças nas linhas de captura
   - Por que cantos e bordas perdem sua importância tradicional?

6. **Metodologia de Análise**
   - Para cada análise descrita em `ANALYSE_PIPELINES.md`, explicar:
     - O que ela mede
     - O que ela pode revelar sobre o comportamento dos agentes
     - Quais insights podem ser extraídos

7. **Considerações Finais**
   - Síntese das contribuições
   - Limitações do estudo
   - Possíveis extensões

### Seções de Exemplo

1. Introdução
   1.1 Contextualização do problema
   1.2 Objetivos do trabalho
   1.3 Estrutura do artigo

2. Othello: Regras e Características
   2.1 Tabuleiro e posicionamento inicial
   2.2 Regras de captura
   2.3 Condição de vitória e final de jogo
   2.4 Importância estratégica das posições

3. Arquitetura dos Agentes de Jogo
   3.1 O Algoritmo Minimax com Poda Alfa-Beta
       3.1.1 Profundidade de busca
       3.1.2 Estados explorados e eficiência da poda
   3.2 O Algoritmo Monte Carlo Tree Search (MCTS)
       3.2.1 Simulações e seleção de nós
       3.2.2 Número de iterações como parâmetro

4. Funções de Avaliação (Heurísticas)
   4.1 Princípio da avaliação posicional
       4.1.1 Visão geral do sistema de pesos
       4.1.2 Por que pesos separados para cada cor?
   4.2 Avaliador de Material (Contagem de Peças)
   4.3 Avaliador de Posição (Regiões do Tabuleiro)
       4.3.1 Mapeamento das seis regiões
       4.3.2 Valores estratégicos por região
   4.4 Avaliador de Mobilidade Potencial (Fronteira)
   4.5 Avaliador de Paridade
   4.6 Avaliador Compositor e Sensível à Fase
   4.7 Avaliadores Ajustados por Aprendizado de Máquina
       4.7.1 Ajuste para vitória (WIN) — Regressão Logística
       4.7.2 Ajuste para pontuação (SCORE) — Regressão Linear
       4.7.3 Processo de treinamento com simulações MCTS×MCTS

5. A Variante com Captura Periódica (WrapAround)
   5.1 Motivação e descrição da regra
   5.2 Representação visual do tabuleiro
   5.3 Implicações estratégicas

6. Análises Realizadas
   6.1 Metodologia de confrontos
   6.2 Resumo estatístico dos jogos
   6.3 Mapas de calor de desempenho (Minimax × MCTS)
   6.4 Análise temporal por profundidade e iterações
   6.5 Padrões de posicionamento e captura

7. Considerações Finais

## 6. Orientações por Seção

### 6.1 Introdução

O agente deve contextualizar o problema de jogos de tabuleiro e a importância de algoritmos de busca. Deve mencionar por que Othello foi escolhido como domínio de estudo e qual a relevância de comparar dois paradigmas diferentes (busca determinística vs. busca probabilística).

### 6.2 Othello

O agente deve explicar as regras de forma clara, incluindo:
- O tabuleiro 6×6 (diferente do Othello padrão 8×8)
- Posicionamento inicial em diagonal
- Regra de captura em linha reta em 8 direções
- Passagem de vez quando um jogador não tem movimentos
- Vitória pela contagem de peças no final

O agente **DEVE** incluir uma representação ASCII do tabuleiro inicial.

### 6.3 Agentes

**Minimax:** Explicar que o algoritmo funciona explorando a árvore de jogos até uma profundidade máxima, aplicando a avaliação em nós folhas e propagando os valores de volta. Deve mencionar a poda alfa-beta como otimização. Deve explicar que o Minimax utiliza uma função de avaliação (heurística) para estimar a qualidade de posições não-terminais.

**MCTS:** Explicar as quatro fases: seleção, expansão, simulação e retropropagação. Deve mencionar que o algoritmo não usa heurísticas explícitas, mas sim simulações aleatórias para guiar a busca. Deve explicar que o número de iterações controla o trade-off entre qualidade da decisão e tempo de cálculo.

### 6.4 Heurísticas

Para **cada** avaliador, o agente deve explicar:
- O que ele mede (parâmetros)
- Como calcula esses parâmetros
- O que significa uma pontuação alta vs. baixa
- Por que esse fator é relevante no Othello

**Sistema de pesos — Explicação Obrigatória:**

O agente deve explicar detalhadamente o mecanismo de pesos:

> Cada avaliador mantém um vetor de pesos que indica a importância de cada parâmetro calculado. A pontuação final é a soma do produto entre cada peso e seu parâmetro correspondente. Importantly, a maioria dos avaliadores possui pesos **separados** para peças brancas e peças pretas. Isso significa que o modelo pode aprender estratégias assimétricas: por exemplo, pode aprender que ter peças brancas no canto é muito valioso (+1.0), mas também pode aprender que ter peças pretas no canto também é muito valioso (-1.0, pois quando negativo significa que a posição é boa para as brancas). Essa independências permite capturar nuances estratégicas onde cada cor pode valorizar fatores diferentes.

O agente deve usar o avaliador de material como exemplo:
> No avaliador de material (SCE1), os pesos padrão são [1.0, -1.0]. Isso significa que cada peça branca contribui +1.0 para a pontuação, e cada peça preta contribui -1.0. Assim, uma posição com 10 peças brancas e 8 pretas teria pontuação 10×1.0 + 8×(-1.0) = 2.0, indicando vantagem para as brancas.

O agente deve explicar também os avaliadores compostos e sensíveis à fase:
> O avaliador CEE1 combina múltiplos avaliadores simples, cada um com seus próprios pesos. Além disso, ele é sensível à fase do jogo: possui três conjuntos de avaliadores (um para abertura, um para meio-jogo, um para final), e ativa apenas o conjunto apropriado conforme o número de casas vazias no tabuleiro.

**Avaliadores ajustados:**

O agente deve explicar o processo de treinamento:

> Os avaliadores CWTE1 e CSTE1 foram obtidos através de aprendizado de máquina sobre uma base de 600 jogos realizados entre agentes MCTS com 10.000 iterações. O ajuste WIN (usado em CWTE1 e WWTE1) utiliza regressão logística para encontrar pesos que maximizem a probabilidade de vitória. O ajuste SCORE (usado em CSTE1 e WSTE1) utiliza regressão linear para encontrar pesos que maximizem a diferença final de peças. Os pesos aprendidos são completamente diferentes dos pesos padrão, revelando estratégias otimizadas empiricamente.

### 6.5 Othello Circular

O agente deve explicar a variante com entusiasmo:

> A variante Othello Circular modifica as regras de captura tradicional. Quando uma peça está posicionada exatamente sobre uma das diagonais principais do tabuleiro (a diagonal que vai do canto superior esquerdo ao inferior direito, ou a diagonal que vai do canto superior direito ao inferior esquerdo), as linhas de visão dessa peça atravessam as bordas do tabuleiro e reaparecem do outro lado. Isso significa que uma peça no canto superior esquerdo, por exemplo, enxerga casas do canto inferior direito através da diagonal, criando capturas.circulares.

O agente **DEVE** incluir um diagrama ASCII mostrando:
1. O tabuleiro inicial da variante (peças nos cantos)
2. Um exemplo de captura que atravessa as bordas

O agente deve discutir as implicações estratégicas:
- Cantos perdem sua segurança tradicional
- Estratégias de controle de bordas se tornam irrelevantes
- Novas táticas de captura circular surgem

### 6.6 Metodologia de Análise

O agente deve descrever cada uma das análises de `ANALYSE_PIPELINES.md`:

1. **Resumo Estatístico:** Explica que fornece visão consolidada do volume de jogos, turnos jogados, tempo gasto, e desempenho por confronto (taxa de vitória, derrotas, empates).

2. **Mapa de Calor de Vitória:** Explica que permite visualizar como a profundidade do Minimax e o número de iterações do MCTS afetam o resultado, revelando zonas de dominance entre os algoritmos.

3. **Tempo Médio do Minimax:** Explica que mostra como o custo computacional cresce com a profundidade, permitindo escolher configurações com melhor relação desempenho/tempo.

4. **Tempo Médio do MCTS:** Explica que demonstra a escalabilidade temporal do algoritmo conforme o número de iterações aumenta.

5. **Tempo Médio por Turno:** Explica que revela em quais fases do jogo cada agente fica mais lento, identificando padrões de complexidade.

6. **Estados Explorados pelo Minimax:** Explica que mede o custo de exploração e ajuda a comparar a eficiência de diferentes avaliadores.

7. **Estados Explorados vs. Podados:** Explica que avalia a eficácia da poda alfa-beta em cada nível da árvore de busca.

8. **Mapa de Calor de Posicionamento:** Explica que expõe preferências espaciais dos agentes, revelando se они preferem cantos, bordas, centro, etc.

9. **Mapa de Calor de Captura:** Explica que mostra zonas de pressão tática, identificando onde os agentes convertem peças do oponente.

---

## 7. Critérios de Qualidade

O artigo será avaliado com base nos seguintes critérios:

1. **Coerência conceitual:** Todas as explicações devem ser consistentes e tecnicamente corretas.
2. **Clareza:** O texto deve ser acessível sem ser superficial.
3. **Completude:** Todos os avaliadores e suas configurações devem ser explicados.
4. **Foco em conceitos:** Nenhuma menção a nomes de classes ou estruturas de código.
5. **Uso de pesos:** Explicação clara e correta do mecanismo de pesos e da razão de existirem pesos separados.
6. **Diagramas:** Incluir representações ASCII do tabuleiro inicial e da variante Othello Circular.

---

## 8. Formato de Entrega

Ao gerar o plano, o agente deve apresentar:

1. **Lista de seções e subseções** (em texto corrido, não em formato bullet)
2. **Breve justificativa** de por que cada seção é necessária

Ao escrever o artigo, o agente deve:

1. Usar заголовки de seção claros
2. Manter parágrafos fluidos
3. Incluir todos os diagramas ASCII necessários
4. Numerar as seções para facilitar referência

---

## 9. Exemplo de Estilo de Escrita

**Bom (texto corrido):**

> O avaliador de material é a heurística mais simples do sistema, calculando a diferença entre o número de peças brancas e pretas no tabuleiro. Cada peça branca contribui positivamente para a pontuação, enquanto cada peça preta contribui negativamente, de modo que uma pontuação positiva indica vantagem para as peças brancas. Essa métrica captura a vantagem material direta, sendo especialmente útil no final do jogo quando poucas peças permanecem.

**Ruim (listas e enumerações):**

> O avaliador de material:
> - Conta peças brancas
> - Conta peças pretas
> - Calcula diferença
> - Retorna pontuação

---

## 10. Checklist de Revisão

Antes de enviar o artigo, o agente deve verificar:

- [ ] Todas as seções obrigatórias estão presentes?
- [ ] Todas as explicações estão em texto corrido?
- [ ] Nenhum nome de classe foi mencionado?
- [ ] Os pesos foram explicados corretamente (incluindo pesos separados)?
- [ ] Todos os avaliadores (SCE1, CEE1, CWTE1, CSTE1, WWTE1, WSTE1) foram descritos?
- [ ] Os processos de treinamento WIN e SCORE foram explicados?
- [ ] A variante Othello Circular foi descrita com diagrama ASCII?
- [ ] Todas as análises foram descritas?
- [ ] O artigo está em português brasileiro formal?

---

## 11. Resultado Esperado

O agente deve entregar:

1. **Plano de seções** (para aprovação)
2. **Artigo completo** (após aprovação do plano)

O artigo deve ser suficientemente detalhado para que outra pessoa, sem acesso ao código, compreenda:
- O que foi feito
- Por que foi feito assim
- Quais os conceitos envolvidos
- Quais análises foram realizadas e o que elas podem revelar