You are a software experts that writes clean, readable and organized code. You should understand the project and plan before writing any code.

Context: The project is about leveraging Minimax and Monte Carlo Tree Search (MCTS) to play the game Othello (Reversi) on a 6x6 board. The Minimax works by running until a certain depth and using a heuristic to evaluate the board to a score. These heuristics are contained in an Evaluator class which receives the state of the game and returns a score from the perspective of the white player. A bigger score means that the position is better for white and a smaller score means the position is better for black. In the other hand, the MCTS receives the numbers of iterations. A bunch of simulations have been run creating matchups between Minimax and MCTS varying the depth and the evaluator used by Minimax and the number of iterations used by MCTS. These tests have also been run on a variant of the game called WrapAround which changes how the captures work.

You are responsible for making the analysis of this data which is saved and loader using the Study class. I would like you to create the following analysis pipelines:

Pipelines:

---

Summary:
Prints a summary in text of the matches in the study which should include:
- Total number of matches;
- Total number of turns;
- Total time spent in moves.

For every pair of agents, print from the perspective of the first agent, which is always the black.
- Total wins
- Total losses
- Total draws
- Win rate

Note: Calculate win rates specifically from the perspective of the Black player for every unique Black/White matchup.

---

Win Heatmap:
Make a set of heatmaps plot to show the win rate between Minimax and MCTS. In the X axis, show the number of iterations of the MCTS and, in the Y axis, the depth used by the Minimax.

Create three heatmaps for each evaluator showing different win rates from the perspective of the Minimax:
- When playing as White
- When playing as Black
- When playing as any player

---

Average time taken to move with Minimax:
Make a line plot where each line is a Minimax agent using a different evaluator. In the X axis, show the depth and, in the Y axis, show the average time taken to move.

---

Average time taken to move with MCTS:
Make a line plot. In the X axis, show the number of iterations and, in the Y axis, show the average time taken to move.

---

Average time taken to move each turn:
Make a line plot where each line is a unique agent configuration. In the X axis, show the number of the turn (state.count) and, in the Y axis, show the average time taken to move.

---

Total states explored with Minimax:
Make a line plot where each line is a Minimax agent using a different evaluator. In the X axis, show the depth and, in the Y axis, show the total number of states explored.

---

Average states explored and average states pruned at each depth with Minimax:
Make one stacked bar plot per unique Minimax agent configuration. In the X axis, show the the depth of the search tree and, in the Y axis, the number of states. Each bar should show the average number of states explored and the average number of states pruned at that depth. They should be normalized so each depth has its own scale.

---

Piece placement heatmap:
Make a set of heatmap plots to show where the pieces of an agent are places. The heatmap plot is the board and each square represents the number of times a move placed a piece in that position.

Create three heatmaps for each unique agent configuration showing the piece placement:
- When playing as white
- When playing as black
- When playing as any

---

Piece capture heatmap:
Make a set of heatmap plots to show where an agent captures the pieces. The heatmap plot is the board and each square represents the number of times their move captured a piece in that position.

Create three heatmaps for each unique agent showing the piece capture:
- When playing as white
- When playing as black
- When playing as any

---

Instruction:
- The input study will only have matches with one variant.
- Every legend, title or description in the plots should be in Brazilian Portuguese.
- Every single plot must be saved to its own file inside a subfolder named after the pipeline. NO subplots combining different graphs into one image file. You can create subfolders inside the subfolder of the pipeline to organize the graphs.
- You have total permission to create helper functions, recommend library installations, and structure the code as needed.

QA:
- Understand each implementation pipeline you have written and check again if it is implementing what you expect.

Document:
After implementing the code, write a formal Markdown document explaining what you have done for each requested pipeline. For each pipeline, describe:
- What the analysis presents.
- What you expect the outcome/graph to look like.
- What insights this specific analysis will provide regarding the agent's behavior.